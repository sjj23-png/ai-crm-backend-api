import { z } from "zod";
import { createContactSchema } from "./create-contact.validator";

export const updateContactSchema =
  createContactSchema.partial();

export type UpdateContactInput = z.infer<
  typeof updateContactSchema
>;
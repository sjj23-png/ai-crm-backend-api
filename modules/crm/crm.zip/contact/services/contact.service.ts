import { ContactRepository } from "../repositories/contact.repository";
import { CreateContactDto } from "../dto/create-contact.dto";

export class ContactService{

  private repository =
  new ContactRepository();

  async create(
    data:CreateContactDto
  ){

    const exists =
    await this.repository.findByEmail(

      data.tenantId,

      data.email

    );

    if(exists){

      throw new Error(
        "Contact email already exists."
      );

    }

    return this.repository.create({

      ...data,

      publicId:"CNT-TODO",

      status:"ACTIVE"

    });

  }

  async getCompanyContacts(
    companyId:string
  ){

    return this.repository.findByCompany(
      companyId
    );

  }

}
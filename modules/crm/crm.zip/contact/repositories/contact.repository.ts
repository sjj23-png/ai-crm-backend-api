import prisma from "../../../../database/prisma.service";


export class ContactRepository {

  create(data:any){

    return prisma.contact.create({

      data

    });

  }

  findByEmail(

    tenantId:string,

    email:string

  ){

    return prisma.contact.findFirst({

      where:{

        tenantId,

        email

      }

    });

  }

  findByCompany(companyId:string){

    return prisma.contact.findMany({

      where:{

        companyId

      },

      include:{

        company:true

      }

    });

  }

}
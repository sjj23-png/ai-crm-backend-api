import { z } from "zod";


export const CreateContactSchema = z.object({

  tenantId: z.string().cuid(),

  companyId: z.string().cuid(),

  ownerId: z.string().cuid(),

  teamId: z.string().cuid(),

  firstName: z.string().min(2).max(100),

  lastName: z.string().optional(),

  jobTitle: z.string().optional(),

  email: z.string().email(),

  phone: z.string().optional(),

  mobile: z.string().optional(),

  department: z.string().optional()

});

export type CreateContactDto =
z.infer<typeof CreateContactSchema>;
import prisma from "../../../../database/prisma.service";


export class DealRepository {

  create(data: any) {

    return prisma.deal.create({

      data,

      include: {

        company: true,

        contact: true,

        owner: true,

        team: true,

        pipeline: true,

        stage: true

      }

    });

  }

  update(
    id: string,
    data: any
  ) {

    return prisma.deal.update({

      where: {

        id

      },

      data,

      include: {

        company: true,

        contact: true,

        owner: true,

        team: true,

        pipeline: true,

        stage: true

      }

    });

  }

  findById(id: string) {

    return prisma.deal.findUnique({

      where: {

        id

      },

      include: {

        company: true,

        contact: true,

        lead: true,

        owner: true,

        team: true,

        pipeline: true,

        stage: true

      }

    });

  }

  findAll(
    tenantId: string
  ) {

    return prisma.deal.findMany({

      where: {

        tenantId,

        deletedAt: null

      },

      include: {

        company: true,

        contact: true,

        owner: true,

        stage: true

      },

      orderBy: {

        createdAt: "desc"

      }

    });

  }

  softDelete(id: string) {

    return prisma.deal.update({

      where: {

        id

      },

      data: {

        deletedAt: new Date(),

        status: "CANCELLED"

      }

    });

  }

}
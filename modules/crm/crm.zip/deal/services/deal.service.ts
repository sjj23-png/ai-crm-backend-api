import { DealRepository } from "../repositories/deal.repository";
import { CreateDealDto } from "../dto/create-deal.dto";

import { UpdateDealDto } from "../dto/update-deal.dto";

export class DealService {

  private repository =
    new DealRepository();

  async createDeal(
    data: CreateDealDto
  ) {

    const finalAmount =
      (data.amount - data.discount) + data.tax;

    return this.repository.create({

      ...data,

      publicId: "DEAL-TODO",

      finalAmount,

      status: "OPEN"

    });

  }

  async updateDeal(

    id: string,

    data: UpdateDealDto

  ) {

    let finalAmount;

    if (

      data.amount !== undefined ||

      data.discount !== undefined ||

      data.tax !== undefined

    ) {

      finalAmount =

        (data.amount ?? 0)

        -

        (data.discount ?? 0)

        +

        (data.tax ?? 0);

    }

    return this.repository.update(

      id,

      {

        ...data,

        ...(finalAmount !== undefined && {

          finalAmount

        })

      }

    );

  }

  async getDeal(id: string) {

    const deal =

      await this.repository.findById(id);

    if (!deal) {

      throw new Error(

        "Deal not found."

      );

    }

    return deal;

  }

  async getDeals(

    tenantId: string

  ) {

    return this.repository.findAll(

      tenantId

    );

  }

  async moveStage(

    id: string,

    stageId: string,

    probability: number

  ) {

    return this.repository.update(

      id,

      {

        stageId,

        probability

      }

    );

  }

  async changeOwner(

    id: string,

    ownerId: string

  ) {

    return this.repository.update(

      id,

      {

        ownerId

      }

    );

  }

  async markWon(

    id: string,

    wonReason: string

  ) {

    return this.repository.update(

      id,

      {

        status: "WON",

        wonReason,

        probability: 100,

        actualCloseDate:

          new Date()

      }

    );

  }

  async markLost(

    id: string,

    lostReason: string

  ) {

    return this.repository.update(

      id,

      {

        status: "LOST",

        lostReason,

        probability: 0,

        actualCloseDate:

          new Date()

      }

    );

  }

  async archiveDeal(

    id: string

  ) {

    return this.repository.softDelete(

      id

    );

  }

}
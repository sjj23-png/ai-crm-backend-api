import { Router } from "express";
import { authGuard } from "../../auth/guards/auth.guard";

import { DealController } from "./controllers/deal.controller";

const router = Router();

const controller =
  new DealController();

router.post(
  "/deals",
  authGuard,
  controller.create
);

router.get(
  "/deals",
  authGuard,
  controller.getAll
);

router.get(
  "/deals/:id",
  authGuard,
  controller.getById
);

router.put(
  "/deals/:id",
  authGuard,
  controller.update
);

router.patch(
  "/deals/:id/stage",
  authGuard,
  controller.moveStage
);

router.patch(
  "/deals/:id/owner",
  authGuard,
  controller.changeOwner
);

router.patch(
  "/deals/:id/won",
  authGuard,
  controller.markWon
);

router.patch(
  "/deals/:id/lost",
  authGuard,
  controller.markLost
);

router.delete(
  "/deals/:id",
  authGuard,
  controller.archive
);

export default router;
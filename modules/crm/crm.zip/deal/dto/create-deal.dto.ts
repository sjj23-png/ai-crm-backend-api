import { z } from "zod";


export const CreateDealSchema = z.object({

  tenantId: z.string().cuid(),

  companyId: z.string().cuid(),

  contactId: z.string().cuid(),

  leadId: z.string().cuid().optional(),

  pipelineId: z.string().cuid(),

  stageId: z.string().cuid(),

  ownerId: z.string().cuid(),

  teamId: z.string().cuid(),

  title: z.string()
    .min(3)
    .max(200),

  description: z.string().optional(),

  amount: z.number().nonnegative(),

  discount: z.number().nonnegative().default(0),

  tax: z.number().nonnegative().default(0),

  currency: z.enum([
    "INR",
    "USD",
    "EUR",
    "GBP",
    "AED",
    "SGD",
    "AUD",
    "CAD"
  ]),

  probability: z.number()
    .min(0)
    .max(100),

  priority: z.enum([
    "LOW",
    "MEDIUM",
    "HIGH",
    "URGENT"
  ]),

  source: z.enum([
    "Website",
    "Referral",
    "LinkedIn",
    "Facebook",
    "Google Ads",
    "Cold Call",
    "Email Campaign",
    "Import",
    "API",
    "Manual",
    "Other"
  ]),

  expectedCloseDate: z.coerce.date(),

  lostReason: z.string().optional(),

  wonReason: z.string().optional()

});

export type CreateDealDto =
z.infer<typeof CreateDealSchema>;
import { Request, Response } from "express";
import { DealService } from "../services/deal.service";

export class DealController {

  private service =
    new DealService();

  create = async (
    req: Request,
    res: Response
  ) => {

    try {

      const deal =
        await this.service.createDeal(
          req.body
        );

      return res.status(201).json(deal);

    } catch (error: any) {

      return res.status(400).json({

        message: error.message

      });

    }

  };

  update = async (
    req: Request,
    res: Response
  ) => {

    try {

      const deal =
        await this.service.updateDeal(

          req.params.id as string,

          req.body

        );

      return res.json(deal);

    } catch (error: any) {

      return res.status(400).json({

        message: error.message

      });

    }

  };

  getAll = async (
    req: Request,
    res: Response
  ) => {

    const deals =
      await this.service.getDeals(

        req.user!.tenantId

      );

    return res.json(deals);

  };

  getById = async (
    req: Request,
    res: Response
  ) => {

    try {

      const deal =
        await this.service.getDeal(

          req.params.id as string

        );

      return res.json(deal);

    } catch (error: any) {

      return res.status(404).json({

        message: error.message

      });

    }

  };

  moveStage = async (
    req: Request,
    res: Response
  ) => {

    const {

      stageId,

      probability

    } = req.body;

    const deal =
      await this.service.moveStage(

        req.params.id as string,

        stageId,

        probability

      );

    return res.json(deal);

  };

  changeOwner = async (
    req: Request,
    res: Response
  ) => {

    const deal =
      await this.service.changeOwner(

        req.params.id as string,

        req.body.ownerId

      );

    return res.json(deal);

  };

  markWon = async (
    req: Request,
    res: Response
  ) => {

    const deal =
      await this.service.markWon(

        req.params.id as string,

        req.body.wonReason

      );

    return res.json(deal);

  };

  markLost = async (
    req: Request,
    res: Response
  ) => {

    const deal =
      await this.service.markLost(

        req.params.id as string,

        req.body.lostReason

      );

    return res.json(deal);

  };

  archive = async (
    req: Request,
    res: Response
  ) => {

    const deal =
      await this.service.archiveDeal(

        req.params.id as string

      );

    return res.json(deal);

  };

}
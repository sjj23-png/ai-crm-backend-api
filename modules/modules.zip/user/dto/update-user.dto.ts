export class UpdateUserDto {
  name?: string;
  phone?: string;
  roleId?: string;
  status?: "ACTIVE" | "INACTIVE" | "SUSPENDED";
}
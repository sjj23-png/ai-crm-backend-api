import prisma from "../../../database/prisma.service";

export class UserRepository {

  create(data: {
    name: string;
    email: string;
    passwordHash: string;
    tenantId: string;
    roleId: string;
  }) {

    return prisma.user.create({
      data
    });

  }

  findById(id: string) {

    return prisma.user.findUnique({

      where: { id },

      include: {
        tenant: true,
        role: true,
        profile: true
      }

    });

  }

  findByEmail(email: string) {

    return prisma.user.findUnique({

      where: { email }

    });

  }

  findAll(tenantId: string) {

    return prisma.user.findMany({

      where: {
        tenantId
      },

      include: {
        role: true,
        profile: true
      },

      orderBy: {
        createdAt: "desc"
      }

    });

  }

  update(id: string, data: any) {

    return prisma.user.update({

      where: { id },

      data

    });

  }

  delete(id: string) {

    return prisma.user.delete({

      where: { id }

    });

  }

}
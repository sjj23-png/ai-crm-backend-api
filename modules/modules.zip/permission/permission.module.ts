import { Router } from "express";
import { authGuard } from "../auth/guards/auth.guard";
import { PermissionController } from "./controller/permission.controller";

const router = Router();
const controller = new PermissionController();

router.post("/", authGuard, controller.create);

router.get("/", authGuard, controller.getAll);

router.get("/:id", authGuard, controller.getById);

router.delete("/:id", authGuard, controller.delete);

export default router;
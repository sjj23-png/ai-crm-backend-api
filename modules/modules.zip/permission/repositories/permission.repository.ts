import prisma from "../../../database/prisma.service";

export class PermissionRepository {
  async create(data: {
    name: string;
    code: string;
    module: string;
    description?: string;
  }) {
    return prisma.permission.create({
      data,
    });
  }

  async findByCode(code: string) {
    return prisma.permission.findUnique({
      where: { code },
    });
  }

  async findById(id: string) {
    return prisma.permission.findUnique({
      where: { id },
    });
  }

  async findAll() {
    return prisma.permission.findMany({
      orderBy: {
        module: "asc",
      },
    });
  }

  async delete(id: string) {
    return prisma.permission.delete({
      where: { id },
    });
  }
}
import { z } from "zod";

export const CreatePermissionSchema = z.object({
  name: z.string().min(2).max(100),
  code: z.string().min(2).max(100),
  module: z.string().min(2).max(100),
  description: z.string().optional(),
});

export type CreatePermissionDto = z.infer<typeof CreatePermissionSchema>;
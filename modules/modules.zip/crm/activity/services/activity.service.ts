import { ActivityRepository } from "../repositories/activity.repository";
import { CreateActivityDto } from "../dto/create-activity.dto";

export class ActivityService {

  private repository =
    new ActivityRepository();

  async createActivity(
    data: CreateActivityDto
  ) {

    return this.repository.create({

      ...data,

      publicId: "ACT-TODO"

    });

  }

  async getDealActivities(
    dealId: string
  ) {

    return this.repository.findByDeal(
      dealId
    );

  }

  async getCompanyActivities(
    companyId: string
  ) {

    return this.repository.findByCompany(
      companyId
    );

  }

  async deleteActivity(
    id: string
  ) {

    return this.repository.softDelete(
      id
    );

  }

}
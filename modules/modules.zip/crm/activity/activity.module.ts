import { Router } from "express";
import { authGuard } from "../../auth/guards/auth.guard";

import { ActivityController } from "./controllers/activity.controller";

const router = Router();

const controller =
  new ActivityController();

router.post(
  "/activities",
  authGuard,
  controller.create
);

router.get(
  "/deals/:dealId/activities",
  authGuard,
  controller.getDealActivities
);

router.get(
  "/companies/:companyId/activities",
  authGuard,
  controller.getCompanyActivities
);

router.delete(
  "/activities/:id",
  authGuard,
  controller.delete
);

export default router;
import prisma from "../../../../database/prisma.service";


export class ActivityRepository {

  create(data: any) {

    return prisma.activity.create({

      data

    });

  }

  findByDeal(
    dealId: string
  ) {

    return prisma.activity.findMany({

      where: {

        dealId,

        deletedAt: null

      },

      include: {

        user: true

      },

      orderBy: {

        activityDate: "desc"

      }

    });

  }

  findByCompany(
    companyId: string
  ) {

    return prisma.activity.findMany({

      where: {

        companyId,

        deletedAt: null

      },

      include: {

        user: true

      },

      orderBy: {

        activityDate: "desc"

      }

    });

  }

  softDelete(id: string) {

    return prisma.activity.update({

      where: {

        id

      },

      data: {

        deletedAt:

          new Date()

      }

    });

  }

}
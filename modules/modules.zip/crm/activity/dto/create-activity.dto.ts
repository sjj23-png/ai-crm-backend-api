import { z } from "zod";


export const CreateActivitySchema = z.object({

  tenantId: z.string().cuid(),

  companyId: z.string().cuid().optional(),

  contactId: z.string().cuid().optional(),

  leadId: z.string().cuid().optional(),

  dealId: z.string().cuid().optional(),

  userId: z.string().cuid(),

  activityType: z.enum([

    "CALL",

    "MEETING",

    "EMAIL",

    "SMS",

    "WHATSAPP",

    "NOTE",

    "TASK",

    "FILE",

    "COMMENT",

    "CREATED",

    "UPDATED",

    "ASSIGNED",

    "STAGE_CHANGED",

    "STATUS_CHANGED",

    "DEAL_WON",

    "DEAL_LOST",

    "OTHER"

  ]),

  title: z.string()

    .min(2)

    .max(200),

  description:

    z.string().optional(),

  activityDate:

    z.coerce.date(),

  metadata:

    z.any().optional()

});

export type CreateActivityDto =
z.infer<typeof CreateActivitySchema>;
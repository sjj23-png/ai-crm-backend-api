import { Request, Response } from "express";
import { ActivityService } from "../services/activity.service";

export class ActivityController {

  private service =
    new ActivityService();

  create = async (
    req: Request,
    res: Response
  ) => {

    try {

      const activity =
        await this.service.createActivity(
          req.body
        );

      return res.status(201).json(activity);

    } catch (error: any) {

      return res.status(400).json({

        message: error.message

      });

    }

  };

  getDealActivities = async (
    req: Request,
    res: Response
  ) => {

    const activities =
      await this.service.getDealActivities(
        req.params.dealId as string
      );

    return res.json(activities);

  };

  getCompanyActivities = async (
    req: Request,
    res: Response
  ) => {

    const activities =
      await this.service.getCompanyActivities(
        req.params.companyId as string
      );

    return res.json(activities);

  };

  delete = async (
    req: Request,
    res: Response
  ) => {

    const activity =
      await this.service.deleteActivity(
        req.params.id as string
      );

    return res.json(activity);

  };

}
import prisma from "../../../../database/prisma.service";


export class StageRepository {

  create(data:any){

    return prisma.stage.create({

      data

    });

  }

  findByPipeline(
    pipelineId:string
  ){

    return prisma.stage.findMany({

      where:{

        pipelineId,

        deletedAt:null

      },

      orderBy:{

        displayOrder:"asc"

      }

    });

  }

  findById(id:string){

    return prisma.stage.findUnique({

      where:{id}

    });

  }

}
import { Request, Response } from "express";
import { StageService } from "../services/stage.service";

export class StageController {

  private service =
  new StageService();

  create = async(
    req:Request,
    res:Response
  )=>{

    const result =
    await this.service.create(
      req.body
    );

    return res.status(201).json(result);

  };

  getPipelineStages = async(
    req:Request,
    res:Response
  )=>{

    const result =
    await this.service.getPipelineStages(
      req.params.pipelineId as string
    );

    return res.json(result);

  };

}
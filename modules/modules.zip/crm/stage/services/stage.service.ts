import { StageRepository } from "../repositories/stage.repository";
import { CreateStageDto } from "../dto/create-stage.dto";

export class StageService{

  private repository =
  new StageRepository();

  async create(
    data:CreateStageDto
  ){

    return this.repository.create({

      ...data,

      publicId:"STG-TODO",

      status:"ACTIVE"

    });

  }

  async getPipelineStages(
    pipelineId:string
  ){

    return this.repository.findByPipeline(
      pipelineId
    );

  }

}
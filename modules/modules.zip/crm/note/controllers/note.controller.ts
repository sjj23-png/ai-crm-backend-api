import { Request, Response } from "express";
import { NoteService } from "../services/note.service";

export class NoteController {

  private service = new NoteService();

  create = async (
    req: Request,
    res: Response
  ) => {

    try {

      const note =
        await this.service.createNote(
          req.body
        );

      return res.status(201).json(note);

    } catch (error: any) {

      return res.status(400).json({
        message: error.message
      });

    }

  };

  getAll = async (
    req: Request,
    res: Response
  ) => {

    const notes =
      await this.service.getNotes(
        req.user!.tenantId
      );

    return res.json(notes);

  };

  getById = async (
    req: Request,
    res: Response
  ) => {

    try {

      const note =
        await this.service.getNote(
          req.params.id as string
        );

      return res.json(note);

    } catch (error: any) {

      return res.status(404).json({
        message: error.message
      });

    }

  };

  delete = async (
    req: Request,
    res: Response
  ) => {

    const note =
      await this.service.deleteNote(
        req.params.id as string
      );

    return res.json(note);

  };

}
import { NoteRepository } from "../repositories/note.repository";
import { CreateNoteDto } from "../dto/create-note.dto";

export class NoteService {

  private repository =
    new NoteRepository();

  async createNote(
    data:CreateNoteDto
  ){

    return this.repository.create({

      ...data,

      publicId:"NOTE-TODO"

    });

  }

  async getNote(id:string){

    const note =
      await this.repository.findById(id);

    if(!note){

      throw new Error(
        "Note not found."
      );

    }

    return note;

  }

  async getNotes(
    tenantId:string
  ){

    return this.repository.findAll(
      tenantId
    );

  }

  async deleteNote(
    id:string
  ){

    return this.repository.softDelete(
      id
    );

  }

}
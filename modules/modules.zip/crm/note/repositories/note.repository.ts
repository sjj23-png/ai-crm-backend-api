import prisma from "../../../../database/prisma.service";


export class NoteRepository {

  create(data:any){

    return prisma.note.create({

      data,

      include:{

        author:true,

        company:true,

        contact:true,

        lead:true,

        deal:true

      }

    });

  }

  update(id:string,data:any){

    return prisma.note.update({

      where:{id},

      data

    });

  }

  findById(id:string){

    return prisma.note.findUnique({

      where:{id},

      include:{

        author:true,

        company:true,

        contact:true,

        lead:true,

        deal:true

      }

    });

  }

  findAll(
    tenantId:string
  ){

    return prisma.note.findMany({

      where:{

        tenantId,

        deletedAt:null

      },

      include:{

        author:true,

        deal:true

      },

      orderBy:{

        createdAt:"desc"

      }

    });

  }

  softDelete(id:string){

    return prisma.note.update({

      where:{id},

      data:{

        deletedAt:new Date()

      }

    });

  }

}
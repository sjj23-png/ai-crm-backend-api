import { Router } from "express";
import { authGuard } from "../../auth/guards/auth.guard";

import { NoteController } from "./controllers/note.controller";

const router = Router();

const controller =
  new NoteController();

router.post(
  "/notes",
  authGuard,
  controller.create
);

router.get(
  "/notes",
  authGuard,
  controller.getAll
);

router.get(
  "/notes/:id",
  authGuard,
  controller.getById
);

router.delete(
  "/notes/:id",
  authGuard,
  controller.delete
);

export default router;
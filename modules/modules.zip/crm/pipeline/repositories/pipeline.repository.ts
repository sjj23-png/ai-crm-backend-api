import prisma from "../../../../database/prisma.service";


export class PipelineRepository{

  create(data:any){

    return prisma.pipeline.create({

      data

    });

  }

  findByName(
    tenantId:string,
    name:string
  ){

    return prisma.pipeline.findFirst({

      where:{
        tenantId,
        name,
        deletedAt:null
      }

    });

  }

  findAll(tenantId:string){

    return prisma.pipeline.findMany({

      where:{
        tenantId,
        deletedAt:null
      },

      include:{
        stages:true
      },

      orderBy:{
        displayOrder:"asc"
      }

    });

  }

}
import { PipelineRepository } from "../repositories/pipeline.repository";
import { CreatePipelineDto } from "../dto/create-pipeline.dto";

export class PipelineService{

  private repository =
  new PipelineRepository();

  async create(
    data:CreatePipelineDto
  ){

    const exists =
    await this.repository.findByName(

      data.tenantId,

      data.name

    );

    if(exists){

      throw new Error(
        "Pipeline already exists."
      );

    }

    return this.repository.create({

      ...data,

      publicId:"PLN-TODO",

      status:"ACTIVE"

    });

  }

  async getAll(
    tenantId:string
  ){

    return this.repository.findAll(
      tenantId
    );

  }

}
import { Request,Response } from "express";
import { PipelineService } from "../services/pipeline.service";

export class PipelineController{

  private service =
  new PipelineService();

  create = async(
    req:Request,
    res:Response
  )=>{

    try{

      const result =
      await this.service.create(
        req.body
      );

      return res.status(201).json(result);

    }

    catch(error:any){

      return res.status(400).json({

        message:error.message

      });

    }

  };

  getAll = async(
    req:Request,
    res:Response
  )=>{

    const result =
    await this.service.getAll(
      req.user!.tenantId
    );

    return res.json(result);

  };

}
import { z } from "zod";


export const CreatePipelineSchema = z.object({

  tenantId: z.string().cuid(),

  name: z.string()
    .min(2)
    .max(100),

  description: z.string().optional(),

  isDefault: z.boolean().optional(),

  displayOrder: z.number().optional()

});

export type CreatePipelineDto =
z.infer<typeof CreatePipelineSchema>;
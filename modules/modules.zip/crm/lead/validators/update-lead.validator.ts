import { z } from "zod";
import { createLeadSchema } from "./create-lead.validator";


export const updateLeadSchema =
  createLeadSchema.partial();

export type UpdateLeadInput = z.infer<
  typeof updateLeadSchema
>;
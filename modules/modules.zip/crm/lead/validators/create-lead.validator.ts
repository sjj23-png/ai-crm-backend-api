import { z } from "zod";


export const createLeadSchema = z.object({
  companyId: z
    .string()
    .cuid()
    .optional(),

  contactId: z
    .string()
    .cuid()
    .optional(),

  ownerId: z
    .string()
    .cuid(),

  teamId: z
    .string()
    .cuid(),

  firstName: z
    .string()
    .trim()
    .min(2),

  lastName: z
    .string()
    .trim()
    .optional(),

  email: z
    .string()
    .email(),

  phone: z
    .string()
    .optional(),

  source: z.enum([
    "WEBSITE",
    "REFERRAL",
    "SOCIAL_MEDIA",
    "EMAIL",
    "PHONE",
    "OTHER",
  ]),

  estimatedValue: z
    .number()
    .optional(),

  expectedCloseDate: z
    .coerce
    .date()
    .optional(),
});

export type CreateLeadInput = z.infer<
  typeof createLeadSchema
>;
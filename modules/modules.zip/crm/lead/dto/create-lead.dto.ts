import { z } from "zod";


export const CreateLeadSchema = z.object({

  tenantId: z.string().cuid(),

  ownerId: z.string().cuid(),

  teamId: z.string().cuid(),

  companyId: z.string().cuid().optional(),

  contactId: z.string().cuid().optional(),

  firstName: z.string().min(2).max(100),

  lastName: z.string().optional(),

  email: z.string().email(),

  phone: z.string().optional(),

  source: z.string(),

  estimatedValue: z.number().optional(),

  expectedCloseDate: z.coerce.date().optional(),

  notes: z.string().optional()

});

export type CreateLeadDto =
z.infer<typeof CreateLeadSchema>;
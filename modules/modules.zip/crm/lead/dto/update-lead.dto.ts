import { CreateLeadDto } from "./create-lead.dto";


export type UpdateLeadDto = Partial<CreateLeadDto>;
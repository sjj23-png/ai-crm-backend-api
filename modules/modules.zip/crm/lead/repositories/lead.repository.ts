import prisma from "../../../../database/prisma.service";


import { CreateLeadDto } from "../dto/create-lead.dto";
import { UpdateLeadDto } from "../dto/update-lead.dto";

export class LeadRepository{

  create(data:any){

    return prisma.lead.create({

      data

    });

  }

  findByEmail(

    tenantId:string,

    email:string

  ){

    return prisma.lead.findFirst({

      where:{

        tenantId,

        email,

        deletedAt:null

      }

    });

  }

  findAll(

    tenantId:string

  ){

    return prisma.lead.findMany({

      where:{

        tenantId,

        deletedAt:null

      },

      include:{

        owner:true,

        team:true,

        company:true,

        contact:true

      },

      orderBy:{

        createdAt:"desc"

      }

    });

  }

  findById(id:string){

    return prisma.lead.findUnique({

      where:{id},

      include:{

        owner:true,

        company:true,

        contact:true,

        team:true

      }

    });
  }
  async update(
    id: string,
    data: UpdateLeadDto
  ) {
    return prisma.lead.update({
      where: {
        id,
      },
      data,
    });
  }

  async delete(id: string) {
    return prisma.lead.update({
      where: {
        id,
      },
      data: {
        deletedAt: new Date(),
      },
    });
  }

}
import { LeadRepository } from "../repositories/lead.repository";
import { CreateLeadDto } from "../dto/create-lead.dto";


import { UpdateLeadDto } from "../dto/update-lead.dto";

export class LeadService{

  private repository =
  new LeadRepository();

  async create(
    data:CreateLeadDto
  ){

    const exists =
    await this.repository.findByEmail(

      data.tenantId,

      data.email

    );

    if(exists){

      throw new Error(

        "Lead already exists."

      );

    }

    return this.repository.create({

      ...data,

      publicId:"LED-TODO",

      status:"NEW",

      score:0

    });

  }

  async getAll(
    tenantId:string
  ){

    return this.repository.findAll(
      tenantId
    );

  }

  async getById(id:string){

    const lead =
    await this.repository.findById(id);

    if(!lead){

      throw new Error(
        "Lead not found."
      );

    }

    return lead;

  }

    async update(
    id: string,
    data: UpdateLeadDto
  ) {
    const existing = await this.repository.findById(id);

    if (!existing) {
      throw new Error("Lead not found");
    }

    return this.repository.update(id, data);
  }

  async delete(id: string) {
    const existing = await this.repository.findById(id);

    if (!existing) {
      throw new Error("Lead not found");
    }

    return this.repository.delete(id);
  }

}
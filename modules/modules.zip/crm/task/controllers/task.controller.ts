import { Request, Response } from "express";
import { TaskService } from "../services/task.service";

export class TaskController {

  private service =
    new TaskService();

  create = async (
    req: Request,
    res: Response
  ) => {

    try {

      const task =
        await this.service.createTask(
          req.body
        );

      return res.status(201).json(task);

    } catch (error: any) {

      return res.status(400).json({
        message: error.message
      });

    }

  };

  getAll = async (
    req: Request,
    res: Response
  ) => {

    const tasks =
      await this.service.getTasks(
        req.user!.tenantId
      );

    return res.json(tasks);

  };

  getById = async (
    req: Request,
    res: Response
  ) => {

    try {

      const task =
        await this.service.getTask(
          req.params.id as string
        ); 

      return res.json(task);

    } catch (error: any) {

      return res.status(404).json({
        message: error.message
      });

    }

  };

  complete = async (
    req: Request,
    res: Response
  ) => {

    const task =
      await this.service.markCompleted(
        req.params.id as string
      );

    return res.json(task);

  };

  delete = async (
    req: Request,
    res: Response
  ) => {

    const task =
      await this.service.deleteTask(
        req.params.id as string
      );

    return res.json(task);

  };

}
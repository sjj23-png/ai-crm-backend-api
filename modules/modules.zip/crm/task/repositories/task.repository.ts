import prisma from "../../../../database/prisma.service";


export class TaskRepository {

  create(data:any){

    return prisma.task.create({

      data,

      include:{

        owner:true,

        assignedTo:true,

        deal:true

      }

    });

  }

  update(
    id:string,
    data:any
  ){

    return prisma.task.update({

      where:{id},

      data

    });

  }

  findById(id:string){

    return prisma.task.findUnique({

      where:{id},

      include:{

        owner:true,

        assignedTo:true,

        company:true,

        contact:true,

        lead:true,

        deal:true

      }

    });

  }

  findAll(
    tenantId:string
  ){

    return prisma.task.findMany({

      where:{

        tenantId,

        deletedAt:null

      },

      include:{

        assignedTo:true,

        deal:true

      },

      orderBy:{

        dueDate:"asc"

      }

    });

  }

  softDelete(id:string){

    return prisma.task.update({

      where:{id},

      data:{

        deletedAt:new Date(),

        status:"CANCELLED"

      }

    });

  }

}
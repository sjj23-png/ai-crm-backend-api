import { z } from "zod";


export const CreateTaskSchema = z.object({

  tenantId: z.string().cuid(),

  companyId: z.string().cuid().optional(),

  contactId: z.string().cuid().optional(),

  leadId: z.string().cuid().optional(),

  dealId: z.string().cuid().optional(),

  ownerId: z.string().cuid(),

  assignedToId: z.string().cuid(),

  title: z.string()
    .min(3)
    .max(200),

  description: z.string().optional(),

  priority: z.enum([
    "LOW",
    "MEDIUM",
    "HIGH",
    "URGENT"
  ]),

  dueDate: z.coerce.date()

});

export type CreateTaskDto =
z.infer<typeof CreateTaskSchema>;
import { Router } from "express";
import { authGuard } from "../../auth/guards/auth.guard";

import { TaskController } from "./controllers/task.controller";

const router = Router();

const controller =
  new TaskController();

router.post(
  "/tasks",
  authGuard,
  controller.create
);

router.get(
  "/tasks",
  authGuard,
  controller.getAll
);

router.get(
  "/tasks/:id",
  authGuard,
  controller.getById
);

router.patch(
  "/tasks/:id/complete",
  authGuard,
  controller.complete
);

router.delete(
  "/tasks/:id",
  authGuard,
  controller.delete
);

export default router;
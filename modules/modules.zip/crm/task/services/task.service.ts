import { TaskRepository } from "../repositories/task.repository";
import { CreateTaskDto } from "../dto/create-task.dto";

export class TaskService {

  private repository =
    new TaskRepository();

  async createTask(
    data:CreateTaskDto
  ){

    return this.repository.create({

      ...data,

      publicId:"TSK-TODO",

      status:"TODO"

    });

  }

  async getTask(id:string){

    const task =
      await this.repository.findById(id);

    if(!task){

      throw new Error(
        "Task not found."
      );

    }

    return task;

  }

  async getTasks(
    tenantId:string
  ){

    return this.repository.findAll(
      tenantId
    );

  }

  async markCompleted(
    id:string
  ){

    return this.repository.update(

      id,

      {

        status:"COMPLETED",

        completedAt:new Date()

      }

    );

  }

  async deleteTask(
    id:string
  ){

    return this.repository.softDelete(
      id
    );

  }

}
import { Router } from "express";
import { authGuard } from "../../auth/guards/auth.guard";

import { CompanyController } from "./controller/company.controller";

const router = Router();

const company =
new CompanyController();

router.post(
"/companies",
authGuard,
company.create
);

router.get(
"/companies",
authGuard,
company.getAll
);

router.get(
"/companies/:id",
authGuard,
company.getById
);

export default router;
import prisma from "../../../../database/prisma.service";


export class CompanyRepository{

  create(data:any){

    return prisma.company.create({

      data

    });

  }

  findById(id:string){

    return prisma.company.findUnique({

      where:{id},

      include:{

        owner:true,

        team:true,

        contacts:true,

        deals:true

      }

    });

  }

  findByName(

    tenantId:string,

    name:string

  ){

    return prisma.company.findFirst({

      where:{

        tenantId,

        name

      }

    });

  }

  findAll(tenantId:string){

    return prisma.company.findMany({

      where:{

        tenantId

      },

      include:{

        owner:true,

        team:true

      },

      orderBy:{

        createdAt:"desc"

      }

    });

  }

}
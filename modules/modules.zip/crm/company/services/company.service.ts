import { CompanyRepository } from "../repositories/company.repository";
import { CreateCompanyDto } from "../dto/create-company.dto";

export class CompanyService{

  private repository =
  new CompanyRepository();

  async create(

    data:CreateCompanyDto

  ){

    const exists =
    await this.repository.findByName(

      data.tenantId,

      data.name

    );

    if(exists){

      throw new Error(

        "Company already exists."

      );

    }

    return this.repository.create({

      ...data,

      publicId:
      await this.generatePublicId(),

      status:"ACTIVE"

    });

  }

  async generatePublicId(){

    const value =
    Date.now();

    return `CMP-${value}`;

  }

  async getAll(

    tenantId:string

  ){

    return this.repository.findAll(

      tenantId

    );

  }

  async getById(id:string){

    const company =
    await this.repository.findById(id);

    if(!company){

      throw new Error(

        "Company not found."

      );

    }

    return company;

  }

}
import { Router } from "express";
import { authGuard } from "../auth/guards/auth.guard";

import { RoleController } from "./controllers/role.controller";
import { RolePermissionController } from "./controllers/role-permission.controller";
const router = Router();
const controller = new RoleController();
const permissionController =
  new RolePermissionController();
router.post("/", authGuard, controller.create);

router.get("/", authGuard, controller.getAll);

router.get("/:id", authGuard, controller.getById);

router.delete("/:id", authGuard, controller.delete);
router.post(
  "/assign-permissions",
  authGuard,
  permissionController.assign
);

router.get(
  "/:roleId/permissions",
  authGuard,
  permissionController.getPermissions
);

router.delete(
  "/:roleId/permissions/:permissionId",
  authGuard,
  permissionController.remove

);
// rolepermission schema




export default router;
import { CreateRoleDto } from "../dto/create-role.dto";
import { RoleRepository } from "../repositories/role.repository";

export class RoleService {
  private readonly repository = new RoleRepository();

  async create(data: CreateRoleDto) {
    const exists = await this.repository.findByName(
      data.name,
      data.tenantId
    );

    if (exists) {
      throw new Error("Role already exists.");
    }

    return this.repository.create(data);
  }

  async getAll(tenantId: string) {
    return this.repository.findAll(tenantId);
  }

  async getById(id: string) {
    const role = await this.repository.findById(id);

    if (!role) {
      throw new Error("Role not found.");
    }

    return role;
  }

  async delete(id: string) {
    await this.repository.delete(id);

    return {
      message: "Role deleted successfully.",
    };
  }
}
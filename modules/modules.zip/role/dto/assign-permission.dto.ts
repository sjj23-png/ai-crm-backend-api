import { z } from "zod";


export const AssignPermissionSchema = z.object({
  roleId: z.string().cuid(),
  permissionIds: z.array(z.string().cuid()).min(1)
});

export type AssignPermissionDto =
  z.infer<typeof AssignPermissionSchema>;
import { z } from "zod";


export const CreateRoleSchema = z.object({
  name: z.string().min(2).max(100),
  description: z.string().optional(),
  tenantId: z.string().cuid(),
});

export type CreateRoleDto = z.infer<typeof CreateRoleSchema>;
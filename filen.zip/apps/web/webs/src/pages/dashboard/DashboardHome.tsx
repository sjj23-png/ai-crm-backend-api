



import {
  BarChart3,
  Building2,
  Briefcase,
  Plus,
  UserPlus,
  Users,
} from "lucide-react";

import {
  DashboardSection,
  KPICard,
  QuickActionCard,
} from "@/components/dashboard";

import {
  KPIGrid,
  RecentActivityWidget,
  RecentLeadWidget,
  ChartPlaceholderWidget,
  EmptyStateWidget,
} from "@/components/dashboard/widgets";

export default function DashboardHome() {
  return (
    <div className="space-y-10">
      <DashboardSection
        title="Overview"
        description="Business performance at a glance"
      >
        <KPIGrid>
          <KPICard
            title="Customers"
            value="1,248"
            trend="+12.5%"
            description="Compared to last month"
            icon={<Users size={22} />}
          />

          <KPICard
            title="New Leads"
            value="326"
            trend="+18%"
            description="This month"
            icon={<UserPlus size={22} />}
          />

          <KPICard
            title="Companies"
            value="84"
            trend="+4%"
            description="Active organizations"
            icon={<Building2 size={22} />}
          />

          <KPICard
            title="Revenue"
            value="$84,250"
            trend="+9%"
            description="Monthly recurring revenue"
            icon={<BarChart3 size={22} />}
          />
        </KPIGrid>
      </DashboardSection>

      <DashboardSection
        title="Quick Actions"
        description="Frequently used operations"
      >
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          <QuickActionCard
            title="Create Lead"
            description="Add a new sales lead."
            icon={<Plus size={22} />}
          />

          <QuickActionCard
            title="Customers"
            description="Manage customer records."
            icon={<Users size={22} />}
          />

          <QuickActionCard
            title="Companies"
            description="Manage organizations."
            icon={<Building2 size={22} />}
          />

          <QuickActionCard
            title="Pipeline"
            description="Open sales pipeline."
            icon={<Briefcase size={22} />}
          />
        </div>
      </DashboardSection>

      <div className="grid gap-6 xl:grid-cols-2">
        <RecentActivityWidget />

        <RecentLeadWidget />
      </div>

      <ChartPlaceholderWidget
        title="Sales Analytics"
      />

      <EmptyStateWidget
        title="Upcoming Tasks"
        description="Tasks and reminders will appear here once the Task module is integrated."
      />
    </div>
  );
}








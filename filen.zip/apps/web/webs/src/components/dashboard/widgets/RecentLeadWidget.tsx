



import {
  UserPlus,
  ChevronRight,
} from "lucide-react";

import WidgetContainer from "../WidgetContainer";

const leads = [
  "Acme Corporation",
  "TechNova Ltd",
  "VisionSoft",
  "Global Systems",
];

export default function RecentLeadWidget() {
  return (
    <WidgetContainer
      title="Recent Leads"
    >
      <div className="space-y-3">
        {leads.map((lead) => (
          <div
            key={lead}
            className="flex items-center justify-between rounded-xl border border-neutral-200 px-4 py-3 dark:border-neutral-800"
          >
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary-100 p-2 text-primary-600 dark:bg-primary-900/30">
                <UserPlus size={18} />
              </div>

              <span>{lead}</span>
            </div>

            <ChevronRight
              size={18}
              className="text-neutral-400"
            />
          </div>
        ))}
      </div>
    </WidgetContainer>
  );
}
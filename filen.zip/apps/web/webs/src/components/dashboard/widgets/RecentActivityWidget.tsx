


import {
  Activity,
  ArrowRight,
} from "lucide-react";

import WidgetContainer from "../WidgetContainer";

const activities = [
  {
    id: 1,
    title: "New customer registered",
    time: "2 minutes ago",
  },
  {
    id: 2,
    title: "Lead moved to Negotiation",
    time: "15 minutes ago",
  },
  {
    id: 3,
    title: "Invoice generated",
    time: "1 hour ago",
  },
];

export default function RecentActivityWidget() {
  return (
    <WidgetContainer
      title="Recent Activity"
      action={
        <button className="text-sm text-primary-600 hover:underline">
          View All
        </button>
      }
    >
      <div className="space-y-4">
        {activities.map((item) => (
          <div
            key={item.id}
            className="flex items-start gap-3"
          >
            <div className="rounded-lg bg-primary-100 p-2 text-primary-600 dark:bg-primary-900/30">
              <Activity size={18} />
            </div>

            <div className="flex-1">
              <p className="font-medium">
                {item.title}
              </p>

              <p className="text-sm text-neutral-500">
                {item.time}
              </p>
            </div>

            <ArrowRight
              size={16}
              className="text-neutral-400"
            />
          </div>
        ))}
      </div>
    </WidgetContainer>
  );
}
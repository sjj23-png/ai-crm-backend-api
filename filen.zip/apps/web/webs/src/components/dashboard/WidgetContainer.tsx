import type { ReactNode } from "react";


interface WidgetContainerProps {
  title?: string;
  action?: ReactNode;
  children: ReactNode;
}

export default function WidgetContainer({
  title,
  action,
  children,
}: WidgetContainerProps) {
  return (
    <div className="rounded-2xl border border-neutral-200 bg-white shadow-sm dark:border-neutral-800 dark:bg-neutral-900">
      {(title || action) && (
        <div className="flex items-center justify-between border-b border-neutral-200 px-6 py-4 dark:border-neutral-800">
          <h3 className="font-semibold">
            {title}
          </h3>

          {action}
        </div>
      )}

      <div className="p-6">
        {children}
      </div>
    </div>
  );
}
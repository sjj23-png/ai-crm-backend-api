import { getDashboardData } from "../utils/dashboard.mapper";



export async function getDashboard() {
  return Promise.resolve(getDashboardData());
}
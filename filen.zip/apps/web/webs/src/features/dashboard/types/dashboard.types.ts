import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";


export interface KPIItem {
  id: string;

  title: string;

  value: string;

  trend: string;

  description: string;

  icon: LucideIcon;
}

export interface QuickActionItem {
  id: string;

  title: string;

  description: string;

  icon: ReactNode;
}

export interface ActivityItem {
  id: number;

  title: string;

  time: string;
}

export interface LeadItem {
  id: number;

  company: string;
}
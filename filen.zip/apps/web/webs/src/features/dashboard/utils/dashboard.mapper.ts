



import {
  dashboardKPIs,
  dashboardQuickActions,
  recentActivities,
  recentLeads,
} from "../data/dashboard.mock";

export function getDashboardData() {
  return {
    kpis: dashboardKPIs,
    quickActions: dashboardQuickActions,
    activities: recentActivities,
    leads: recentLeads,
  };
}